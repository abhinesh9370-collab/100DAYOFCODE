# C Language Coding Challenge

This folder contains my daily practice programs written in C.  
Each day has 1–2 questions related to the topic covered in class.  
All programs are arranged day-wise and cover the full syllabus topics.

---

## Folder Structure
### Coding Challenge/
├── Day01/
├── Day02/
├── …
└── Day40/
## Each file is named like:
d1_q1.c  → Day 1, Question 1
d1_q2.c  → Day 1, Question 2
---

## Topics Covered

- **Basics & Input/Output**
- **Conditional Statements (if–else, switch)**
- **Loops (for, while, do–while)**
- **Nested Loops & Patterns**
- **1D Arrays (searching, inserting, deleting, etc.)**
- **2D Arrays / Matrices (sum, transpose, multiplication, etc.)**

---

## How to Run
To compile and run any program:
```bash
gcc filename.c -o output
./output

gcc d36_q1.c -o run
./run